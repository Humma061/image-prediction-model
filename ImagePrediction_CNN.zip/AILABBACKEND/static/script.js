document.getElementById('uploadForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const input = document.getElementById('imageInput');
    const result = document.getElementById('result');

    if (input.files.length === 0) {
        result.textContent = "Please upload an image first.";
        return;
    }

    const file = input.files[0];
    const formData = new FormData();
    formData.append('file', file);

    result.textContent = "Predicting...";

    fetch('/predict', {
        method: 'POST',
        body: formData,
    })
    .then(response => {
        if (!response.ok) {
            throw new Error("Server error");
        }
        return response.json();
    })
    .then(data => {
        result.textContent = "Prediction: " + data.digit;
    })
    .catch(error => {
        result.textContent = "Error: " + error.message;
    });
});