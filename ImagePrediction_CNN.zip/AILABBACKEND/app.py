from flask import Flask, render_template, request, jsonify
import tensorflow as tf
from PIL import Image
import numpy as np

# Load the model
model = tf.keras.models.load_model('mnist_model.h5')

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('project.html')

@app.route('/predict', methods=['POST'])
def predict():
    if 'file' not in request.files:
        return jsonify({'error': 'No file uploaded'}), 400
    file = request.files['file']
    img = Image.open(file).convert('L').resize((28, 28))
    img_tensor = np.array(img, dtype=np.float32) / 255.0
    img_tensor = 1 - img_tensor  # Invert for MNIST style
    img_tensor = img_tensor.reshape((1, 28, 28, 1))
    prediction = model.predict(img_tensor)
    predicted_digit = int(np.argmax(prediction, axis=1)[0])
    return jsonify({'digit': predicted_digit})

if __name__ == '__main__':
    app.run(debug=True)